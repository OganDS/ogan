<?php 
	$host = "localhost";
	$username = "root";
	$password = "";
	$db = "tiket";
	$connect = mysqli_connect($host, $username, $password, $db) or die (mysqli_error());
 ?>

