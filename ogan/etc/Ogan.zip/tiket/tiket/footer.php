<footer class="page-footer" style="background-color: #0f0f0f;">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">BayPlane</h5>
                <img src="../image/bayplane.png" width="75" height="75">
                <p class="grey-text text-lightent-4">Pesan tiket ke luar negeri hanya dengan 1 klik.</p>
            </div>
            <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Silahkan Ikuti Kami di</h5>
                <ul>
                    <li><a href="#" class="grey-text text-lighten-4" target="_blank"><i class="ion-social-facebook"></i> Facebook</a> <br/></li>
                    <li><a href="#" class="grey-text text-lighten-4" target="_blank"><i class="ion-social-instagram"></i> Instagram</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            &copy; 2018 BayPlane | Repost by <a href="https://stokcoding.com/" title="StokCoding.com" target="_blank">StokCoding.com</a>
        </div>
    </div>
</footer>
